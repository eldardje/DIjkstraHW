# DIjkstraHW

## Overview
This project is a Python implementation of Dijkstra's algorithm. It calculates the shortest path from a source node to all other nodes in a graph.
